﻿using Medic.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;

namespace Medic
{
    public class DrugData
    {
        public static void Initialize()
        {
            string connStr = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\SW\medi.accdb;Persist Security Info=False;";
            DataTable dt;
            using (OleDbConnection conn = new OleDbConnection(connStr))
            {
                conn.Open();
                using (OleDbDataAdapter da = new OleDbDataAdapter())
                {
                    using (OleDbCommand cmd = new OleDbCommand("SELECT * from Sheet3", conn))
                    {
                        cmd.CommandType = CommandType.Text;
                        da.SelectCommand = cmd;
                        DataSet ds = new DataSet();
                        da.Fill(ds);

                        if (ds.Tables.Count > 0)
                        {
                            dt = ds.Tables[0];

                            var qDrugs = from row in dt.AsEnumerable()
                                         select new DrugBasic
                                         {
                                             PRINCIPAL_COMPONENT = row.Field<string>("주성분"),
                                             ITEM_NAME = row.Field<string>("품목명"),
                                             // REMARK = row.Field<string>("비고"),
                                             EE_DOC_DATA = row.Field<string>("약효") + "(" + row.Field<string>("약효분류명") + ")",
                                             ETC_OTC_CODE = row.Field<string>("전문일반"),
                                            // ED_DOC_DATA =  row.Field<string>("약효분류명"),
                                            //  VALID_TERM = row.Field<string>("유효기간"),
                                             NB_DOC_DATA =row.Field<string>("금기내용") + (string.IsNullOrEmpty( row.Field<string>("비고")) ?  "" : "(" + row.Field<string>("비고") + ")"),
                                             // STORE = row.Field<string>("저장방법"),
                                             PROPERTIES = row.Field<string>("병용성상")
                                         };

                            StaticVars.Drugs = qDrugs.ToList();
                        }
                    }
                }
            }
        }

    }
}